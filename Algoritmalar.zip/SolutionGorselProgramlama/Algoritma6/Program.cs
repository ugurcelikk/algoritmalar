﻿using System;

namespace Algoritma6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[10] { -4, 1, 8, 6, -9, 2, 0, -5, -7, 3 };
            shell_Sort(array);
           
        }

        public static void shell_Sort (int[] array)
        {
            int j;
            int temporary;
            int gap = array.Length / 2;


            while (gap > 0)
            {
                for (int i = gap; i < array.Length; i++)
                {
                    temporary = array[i];
                    j = i;
                    while (j >= gap && array[j - gap] > temporary)
                    {
                        array[j] = array[j - gap];
                        j -= gap;
                    }
                    array[j] = temporary;
                }
                gap = gap / 2;
            }

            Console.WriteLine("Dizinin shell sort ile sıralanmış hali:");
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i] + "\t");
            }
            Console.ReadKey();

        }
    }
}
