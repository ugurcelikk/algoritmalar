﻿using System;

namespace Algoritma9
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] d = Radix_Sort(new int[] { 1000, 32, 353, 21, 421 });
            Console.WriteLine("Dizinin radix sort ile sıralanmış hali:");


            for (int i = 0; i < d.Length; i++)
            {
                Console.Write(d[i] + "\t");
            }

            Console.ReadKey();

        }

       public static int[] Radix_Sort(int[] dizi, int b = 1)
        {
            int[] a = new int[10];
            int[] c = new int[dizi.Length];

            int i = 0, ra = 0, p = b * 10, k = 0;

            
            for (i = 0; i < dizi.Length; i++)
            {
                ra = (dizi[i] % p) / b;

                
                if (dizi[i] / p > k)
                    k = dizi[i] / p;
                a[ra]++;
            }

            
            for (i = 1; i < a.Length; i++)
            {
                a[i] += a[i - 1];
            }

           
            for (i = dizi.Length - 1; i >= 0; i--)
            {
                ra = (dizi[i] % p) / b;
                c[--a[ra]] = dizi[i];
            }

             
            if (k > 0)
                return Radix_Sort(c, p);
            return c;
        }
    }
}
