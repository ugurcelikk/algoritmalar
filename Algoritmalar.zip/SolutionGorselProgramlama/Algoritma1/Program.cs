﻿using System;

namespace Algoritma1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] dizi = { 5, 2, -3, 8, -6, -9 };
            Console.WriteLine("Dizinin selection sort ile sıralanmış hali: ");
            selectionSort(dizi);


        }
       public static void selectionSort(int[] dizi)
        {
            int temp = 0;

            for (int i = 0; i < dizi.Length; i++)
            {
                for (int j = i; j < dizi.Length; j++)
                {
                    if (dizi[i] > dizi[j])
                    {
                        temp = dizi[j];
                        dizi[j] = dizi[i];
                        dizi[i] = temp;
                    }
                }
            }
            foreach (int i in dizi)
            {
                Console.Write("\t"+i);
            }
        }
    }

}