﻿using System;

namespace Algoritma5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] dizi = { 6, 8, 3, 10, 7, 2, 4 };
            Console.WriteLine("Dizinin bubble sort ile sıralanmış hali: ");
            Kabarcik(dizi);

            for (int indis = 0; indis < dizi.Length; indis++) 
                Console.Write(dizi[indis] + "\t"); 

            Console.ReadLine();

            static void Kabarcik(int[] A) 
            {

                int takas;

                for (int i = 0; i < A.Length; i++)
                {
                    for (int j = A.Length - 1; j > i; j--) 
                    {
                        if (A[j - 1] > A[j])
                        {
                            takas = A[j - 1];
                            A[j - 1] = A[j];
                            A[j] = takas;
                        }
                    }
                }

            }
        }
    }
}
