﻿using System;

namespace Algoritma8
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] d = CombSort(new int[] { 4, 10, 1, 6, 7 });
            Console.WriteLine("Dizinin comb sort ile sıralanmış hali:");
            for (int i = 0; i < d.Length; i++)
            {
                Console.Write(d[i] + "\t");
            }
            Console.ReadKey();
        }

       public static int[] CombSort(int[] dizi)
        {
            int bosluk = dizi.Length;
            bool degisti = false;
            while (bosluk > 1 || degisti)
            {
                if (bosluk > 1)
                    bosluk = (int)((float)bosluk / 1.3f);

                degisti = false;

                for (int i = 0; i + bosluk < dizi.Length; i++)
                {
                    if (dizi[i + bosluk] < dizi[i])
                    {
                        int temp = dizi[i + bosluk];
                        dizi[i + bosluk] = dizi[i];
                        dizi[i] = temp;
                        degisti = true;
                    }
                }
            }

            return dizi;
        }
    }
}
