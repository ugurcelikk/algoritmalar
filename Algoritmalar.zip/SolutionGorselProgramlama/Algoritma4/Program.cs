﻿using System;

namespace Algoritma4
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int[] dizi = { 12, 3, 8, 5, 15, 12, 45, 31 };
            Console.WriteLine("Dizinin insertion sort ile sıralanmış hali: ");
            insertion_sort(dizi);
        }
       public static void insertion_sort(int[] dizi)
        {
            for (int j = 1; j < dizi.Length; j++)
            {
                int key = dizi[j]; 
                int i = j - 1;  
                while (i >= 0 && dizi[i] > key) 
                {
                    dizi[i + 1] = dizi[i];  
                    i = i - 1;  
                }
                dizi[i + 1] = key;

            }
            for (int i = 0; i < dizi.Length; i++)
            {
                Console.Write(dizi[i] + "\t");
            }

        }
    }
}
