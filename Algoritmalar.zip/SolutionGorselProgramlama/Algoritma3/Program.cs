﻿using System;

namespace Algoritma3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] d = MergeSort(new int[] { 10, 5, 1, 2, 20, 15 });
            Console.WriteLine("Dizinin merge sort ile sıralanmış hali: ");

            for (int i = 0; i < d.Length; i++)
            {
                Console.Write(d[i] + "\t");
            }
            
        }
        static int[] MergeSort(int[] d)
        {
            if (d.Length <= 1)
                return d; 

            int i = 0;
            int bol = d.Length / 2; 

            int[] sol = new int[bol]; 
            int[] sag = new int[d.Length - bol]; 



            for (i = 0; i < bol; i++)
            {
                sol[i] = d[i]; 
            }

            int k = 0;
            for (i = bol; i < d.Length; i++)
            {
                sag[k] = d[i]; 
                k++;
            }

            sol = MergeSort(sol); 
            sag = MergeSort(sag); 

            return birlestir(sol, sag); 
        }

        static int[] birlestir(int[] sol, int[] sag)
        {

            int[] a = new int[sol.Length + sag.Length]; 

            int i = 0, j = 0, k = 0;

            while (j < sol.Length && i < sag.Length)
                a[k++] = (sag[i] > sol[j]) ? sag[i++] : sol[j++];
                                                                 

            while (i < sag.Length)
                a[k++] = sag[i++]; 

            while (j < sol.Length) 
                a[k++] = sol[j++];

            return a; 
        }

    }
}
