﻿using System;

namespace Algoritma2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] dizi = { 84, 6, 4, 27, 50 };
            Console.WriteLine("Dizinin quick sort ile sıralanmış hali: ");
            int[] d = Quick_Sort(dizi,0, 5);

            //Konsola yaz
            for (int i = 0; i < d.Length; i++)
            {
                Console.Write(d[i] + "\t");
            }
            Console.ReadKey();
        }

        public static int[] Quick_Sort(int[] dizi, int sol, int sag)
        {
            int p = dizi[sag - 1], i = sol, j = sag - 2, temp = 0;

            if (sag - sol > 2)
            {
                while (i < j)
                {
                    while (dizi[i] < p) { i++; }

                    while (j > 0 && dizi[j] > p) { j--; }

                    if (i < j)
                    {
                        temp = dizi[i];
                        dizi[i++] = dizi[j];
                        dizi[j--] = temp;
                    }
                }
            }

            if (p < dizi[i])
            {
                temp = dizi[i];
                dizi[i] = dizi[sag - 1];
                dizi[sag - 1] = temp;
            }

            if (i - sol > 1)
                dizi = Quick_Sort(dizi, sol, i);

            if (sag - (i + 1) > 1)
                dizi = Quick_Sort(dizi, i + 1, sag);

            return dizi;
        }
    }
    }

