﻿using System;

namespace Algoritma10
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[] { 7, 3, 5, 1 };
            Console.WriteLine("Dizinin counting sort ile sıralanmış hali:");
            counting_Sort(a);


        }

        public static void counting_Sort(int[] a) {


            
            int enb = 0;
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] > a[enb])
                    enb = i;
            }

           
            int[] b = new int[a[enb] + 1];
            int[] c = new int[a.Length];

            
            for (int i = 0; i < a.Length; i++)
            {
                b[a[i]] += 1;
            }

            
            for (int i = 1; i < b.Length; i++)
            {
                b[i] += b[i - 1];
            }

            
            for (int i = a.Length - 1; i >= 0; i--)
            {
                c[b[a[i]]-- - 1] = a[i];

            }
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + "\t");
            }
        }



































    }
}
