﻿using System;

namespace Algoritma7
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] d = Gnome_Sort(new int[] { 5, 3, 1, 10, 7 });
            Console.WriteLine("Dizinin gnome sort ile sıralanmış hali:");

            for (int i = 0; i < d.Length; i++)
            {
                Console.Write(d[i] + "\t");
            }

            Console.ReadKey();
        }

       public static int[] Gnome_Sort(int[] dizi)
        {
            int i = 0, j = 1;
            while (i < dizi.Length - 1)
            {
                if (i == -1)
                    i = j;

                if (dizi[i + 1] > dizi[i])
                    i = j++;
                else
                {
                    int temp = dizi[i];
                    dizi[i] = dizi[i + 1];
                    dizi[i + 1] = temp;
                    i--;
                }
            }

            return dizi;
        }
    }
}
